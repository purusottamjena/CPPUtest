import os

# Define the project structure and file contents
project_structure = {
    "my_project": {
        "include": {
            "my_math_function.h": """\
#ifndef MY_MATH_FUNCTION_H
#define MY_MATH_FUNCTION_H

#ifdef __cplusplus
extern "C" {
#endif

int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);

#ifdef __cplusplus
}
#endif

#endif
"""
        },
        "src": {
            "my_math_function.c": """\
#include "my_math_function.h"

int add(int a, int b) {
  return a + b;
}

int subtract(int a, int b) {
  return a - b;
}

int multiply(int a, int b) {
    return a * b;
}
"""
        },
        "tests": {
            "CMakeLists.txt": """\
# Add test executable
add_executable(test_my_math_function test_my_math_function.cpp)

# Link GTest and your library
target_link_libraries(test_my_math_function
    gtest
    gtest_main
    pthread
    my_math_function
)

# Add test
add_test(NAME MyMathTests COMMAND test_my_math_function)
""",
            "test_my_math_function.cpp": """\
#include <gtest/gtest.h>
#include "my_math_function.h"

// Test the add function
TEST(MyMathFunctionTest, Add) {
    EXPECT_EQ(add(3, 2), 5);
    EXPECT_EQ(add(-1, 1), 0);
    EXPECT_EQ(add(0, 0), 0);
}

// Test the subtract function
TEST(MyMathFunctionTest, Subtract) {
    EXPECT_EQ(subtract(3, 2), 1);
    EXPECT_EQ(subtract(-1, 1), -2);
    EXPECT_EQ(subtract(0, 0), 0);
}

// Test the multiply function
TEST(MyMathFunctionTest, Multiply) {
    EXPECT_EQ(multiply(3, 2), 6);
    EXPECT_EQ(multiply(-1, 1), -1);
    EXPECT_EQ(multiply(0, 5), 0);
}

// Main entry point for tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
"""
        },
        "CMakeLists.txt": """\
cmake_minimum_required(VERSION 3.10)
project(my_project)

# Set C++ standard
set(CMAKE_CXX_STANDARD 17)

# Include directories
include_directories(include)

# Add the library
add_library(my_math_function src/my_math_function.c)

# Add test directory
enable_testing()
add_subdirectory(tests)
""",
        "README.md": """\
# My Project

This project demonstrates the use of CMake and Google Test for testing a simple math library.

## Structure
"""
 }
}

# Function to create files and directories based on the structure
def create_structure(base_path, structure):
 for name, content in structure.items():
     path = os.path.join(base_path, name)
     if isinstance(content, dict):
         # Create a directory
         os.makedirs(path, exist_ok=True)
         create_structure(path, content)  # Recursively handle subdirectories
     else:
         # Create a file and write content
         with open(path, "w") as f:
             f.write(content)

# Main script
if __name__ == "__main__":
 base_dir = "my_project"
 create_structure(".", project_structure)
 print(f"Project structure created at ./{base_dir}")

