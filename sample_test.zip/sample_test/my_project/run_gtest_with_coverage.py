import os
import subprocess
import shutil

# Define paths for build and coverage directories
BUILD_DIR = "build"
COVERAGE_DIR = os.path.join(BUILD_DIR, "coverage")

def run_command(command, cwd=None, capture_output=False):
    """Run a shell command and print output."""
    print(f"Running command: {command}")
    result = subprocess.run(
        command, cwd=cwd, shell=True, text=True,
        stdout=subprocess.PIPE if capture_output else None,
        stderr=subprocess.PIPE if capture_output else None
    )
    if result.returncode != 0:
        print(f"Error: Command failed: {command}")
        if capture_output:
            print(result.stderr)
        exit(1)
    if capture_output:
        return result.stdout.strip()

def setup_build_directory():
    """Create and configure the build directory."""
    if os.path.exists(BUILD_DIR):
        print(f"Cleaning up existing build directory: {BUILD_DIR}")
        shutil.rmtree(BUILD_DIR)
    os.makedirs(BUILD_DIR, exist_ok=True)
    print(f"Build directory created: {BUILD_DIR}")

def run_cmake():
    """Run CMake to configure the build system."""
    print("Running CMake...")
    run_command(
        "cmake .. -DCMAKE_BUILD_TYPE=Debug "
        "-DCMAKE_CXX_FLAGS='--coverage' -DCMAKE_EXE_LINKER_FLAGS='--coverage' "
        "-DCMAKE_VERBOSE_MAKEFILE=ON",
        cwd=BUILD_DIR
    )

def build_project():
    """Build the project using Make."""
    print("Building the project...")
    run_command("make VERBOSE=1", cwd=BUILD_DIR)

def run_tests():
    """Run the GTest tests."""
    print("Running tests...")
    run_command("ctest --output-on-failure", cwd=BUILD_DIR)

def generate_coverage_report():
    """Generate a code coverage report using gcovr."""
    print("Generating code coverage report...")
    os.makedirs(COVERAGE_DIR, exist_ok=True)
    output_file = os.path.join(COVERAGE_DIR, "coverage.html")

    # Verify presence of gcno and gcda files
    gcov_files = run_command("find . -name '*.gcno' -o -name '*.gcda'", cwd=BUILD_DIR, capture_output=True)
    if not gcov_files.strip():
        print("Error: No coverage files (.gcno or .gcda) found. Ensure your project is built and tests are executed.")
        exit(1)

    # Generate the coverage report
    run_command(
        f"gcovr --root {os.path.abspath('..')} --filter={os.path.abspath('../src')} "
        f"--exclude-directories=tests --html --html-details -o {os.path.abspath(output_file)}",
        cwd=BUILD_DIR
    )
    print(f"Coverage report generated at: {os.path.abspath(output_file)}")

def main():
    """Main function to automate the build, test, and coverage generation process."""
    setup_build_directory()
    run_cmake()
    build_project()
    run_tests()
    generate_coverage_report()

if __name__ == "__main__":
    main()

