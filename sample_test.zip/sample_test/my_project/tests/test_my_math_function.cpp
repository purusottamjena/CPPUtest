#include <gtest/gtest.h>
#include "my_math_function.h"

// Test the add function
TEST(MyMathFunctionTest, Add) {
    EXPECT_EQ(add(3, 2), 5);
    EXPECT_EQ(add(-1, 1), 0);
    EXPECT_EQ(add(0, 0), 0);
}

// Test the subtract function
TEST(MyMathFunctionTest, Subtract) {
    EXPECT_EQ(subtract(3, 2), 1);
    EXPECT_EQ(subtract(-1, 1), -2);
    EXPECT_EQ(subtract(0, 0), 0);
}

// Test the multiply function
TEST(MyMathFunctionTest, Multiply) {
    EXPECT_EQ(multiply(3, 2), 6);
    EXPECT_EQ(multiply(-1, 1), -1);
    EXPECT_EQ(multiply(0, 5), 0);
}

// Main entry point for tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
