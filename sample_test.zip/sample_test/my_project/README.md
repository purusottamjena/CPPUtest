# My Project

This project demonstrates the use of CMake and Google Test for testing a simple math library.

## Structure
