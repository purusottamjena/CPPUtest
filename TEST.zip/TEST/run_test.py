import os
import subprocess
import sys
import webbrowser

# Paths and file names
source_files = "my_math_function.c test_my_math_function.cpp"
executable = "test_my_math_function"
coverage_info = "coverage.info"
coverage_report_dir = "coverage_report"

def run_command(command):
    """Utility to run a shell command and handle errors."""
    result = subprocess.run(command, shell=True)
    if result.returncode != 0:
        print(f"Error: Command '{command}' failed.")
        sys.exit(result.returncode)

# Step 1: Compile the code with coverage flags
print("Compiling code with coverage flags...")
compile_command = (
    f"g++ -o {executable} {source_files} -lgtest -lgtest_main -pthread -fprofile-arcs -ftest-coverage"
)
run_command(compile_command)

# Step 2: Run the tests
print("Running tests...")
run_command(f"./{executable}")

# Step 3: Capture the coverage data with lcov
print("Capturing coverage data with lcov...")
run_command(f"lcov --capture --directory . --output-file {coverage_info} --ignore-errors inconsistent,usage")

# Step 4: Generate the HTML coverage report
print("Generating HTML coverage report with genhtml...")
run_command(f"genhtml {coverage_info} --output-directory {coverage_report_dir}")

# Step 5: Open the coverage report
report_path = os.path.join(coverage_report_dir, "index.html")
if os.path.exists(report_path):
    print("Opening the coverage report in a web browser...")
    webbrowser.open(f"file://{os.path.abspath(report_path)}")
else:
    print("Coverage report generation failed.")

