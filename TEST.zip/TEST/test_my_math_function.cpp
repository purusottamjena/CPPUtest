// file: test_my_math_function.cpp
#include <gtest/gtest.h>
#include "my_math_function.h"

// Test cases for the add function
TEST(MyMathTest, AddFunction) {
    EXPECT_EQ(add(3, 2), 5);
    EXPECT_EQ(add(-1, -1), -2);
    EXPECT_EQ(add(0, 0), 0);
}

// Test cases for the subtract function
TEST(MyMathTest, SubtractFunction) {
    EXPECT_EQ(subtract(5, 3), 2);
    EXPECT_EQ(subtract(0, 0), 0);
    EXPECT_EQ(subtract(-1, -1), 0);
}

// Test cases for the multiply function
TEST(MyMathTest, MultiplyFunction) {
    EXPECT_EQ(multiply(3, 2), 6);
    EXPECT_EQ(multiply(-1, 1), -1);
    EXPECT_EQ(multiply(0, 5), 0);
}

// Main function to run tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

