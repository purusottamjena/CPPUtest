import os
import subprocess
import sys

def run_command(command):
    """Utility function to run a shell command and handle errors."""
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print(f"Error running command: {command}")
        print(result.stderr.decode())
        sys.exit(1)
    else:
        print(result.stdout.decode())

def clean_build_directory():
    """Clean and recreate the build directory."""
    if os.path.exists("build"):
        run_command("rm -rf build")
    os.makedirs("build")
    os.chdir("build")

def build_project():
    """Configure and build the project using CMake and Make."""
    print("Configuring project with CMake...")
    run_command("cmake ..")
    print("Building project...")
    run_command("make")

def run_tests():
    """Run the test executable."""
    print("Running tests...")
    run_command("./MyMathTest")

def generate_coverage():
    """Generate coverage data with lcov."""
    print("Capturing coverage data with lcov...")
    run_command("lcov --capture --directory . --output-file coverage.info --ignore-errors inconsistent --ignore-errors usage")

def generate_html_report():
    """Generate HTML report from lcov data."""
    print("Generating HTML report with genhtml...")
    run_command("genhtml coverage.info --output-directory coverage_report")

def open_report():
    """Open the HTML report in a browser."""
    index_path = "coverage_report/index.html"
    if os.path.exists(index_path):
        print("Opening coverage report in the browser...")
        run_command(f"xdg-open {index_path}")
    else:
        print("Error: Coverage report index.html not found.")

if __name__ == "__main__":
    clean_build_directory()
    build_project()
    run_tests()
    generate_coverage()
    generate_html_report()
    open_report()

