#include "CppUTest/TestHarness.h"
#include "my_math_function.h"
#include "CppUTest/CommandLineTestRunner.h"  // Include CommandLineTestRunner for main function
TEST_GROUP(MyMathFunctions) {
};

TEST(MyMathFunctions, TestAdd) {
  CHECK_EQUAL(2, add(1, 1));
  CHECK_EQUAL(0, add(-1, 1));
  CHECK_EQUAL(10, add(5, 5));
  CHECK_EQUAL(-10, add(-5, -5));
  CHECK_EQUAL(0, add(0, 0));
  // Test with larger numbers
  CHECK_EQUAL(20000, add(10000, 10000));
  //Test Overflow (This might depend on your system's int size)
  //CHECK_EQUAL(2147483647 , add(2147483647, 0)); // INT_MAX test, may fail
}


TEST(MyMathFunctions, TestSubtract) {
  CHECK_EQUAL(0, subtract(1, 1));
  CHECK_EQUAL(-2, subtract(-1, 1));
  CHECK_EQUAL(0, subtract(5, 5));
  CHECK_EQUAL(0, subtract(-5, -5));
  CHECK_EQUAL(0, subtract(0, 0));
  CHECK_EQUAL(5, subtract(10,5));
  CHECK_EQUAL(-5, subtract(5,10));

  // Test with larger numbers
  CHECK_EQUAL(0, subtract(10000, 10000));


}

TEST(MyMathFunctions, TestMultiply) {
    CHECK_EQUAL(1, multiply(1, 1));
    CHECK_EQUAL(-1, multiply(-1, 1));
    CHECK_EQUAL(25, multiply(5, 5));
    CHECK_EQUAL(25, multiply(-5, -5));
    CHECK_EQUAL(0, multiply(0, 0));
    CHECK_EQUAL(0, multiply(5,0));
    CHECK_EQUAL(0, multiply(0,5));

    // Test with larger numbers (be mindful of potential overflow)
    CHECK_EQUAL(1000000, multiply(1000, 1000));


}
int main(int argc, char** argv) {
    return CommandLineTestRunner::RunAllTests(argc, argv); // Run all tests defined above
}
